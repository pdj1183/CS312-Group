<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title> Milestone 2 </title>
    <meta name="author" content="Group 7">
    <meta name="description" content="Group milestone site for cs312">
</head>

<section class="banner">
    <div class="content">
        <h1 class="color">We Like Color!</h1>
        <p class="company">
            Here at The Color Company we aim to provide you, the user, with some really fun colors. We think.
            Probably. Anyways here is our site and it should make some colors for you if we did some stuff right!
        </p>
    </div>
</section>

</html>